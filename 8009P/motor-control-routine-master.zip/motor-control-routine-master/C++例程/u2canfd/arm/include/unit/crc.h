//
// Created by Administrator on 24-12-1.
//

#ifndef CRC_H
#define CRC_H
#include <stdint.h>
uint16_t CRC16(uint8_t *puchMsg, uint32_t usDataLen);
#endif //CRC_H

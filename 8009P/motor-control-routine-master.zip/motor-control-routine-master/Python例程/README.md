# 达妙电机python例程

## 介绍

这是控制达妙电机的python例程。

硬件设备需要达妙的**USB转CANFD设备**或者达妙的**USB转CAN设备**，分别对应**u2canfd**文件夹和**u2can**文件夹。

关于代码的安装编译和使用，**u2canfd**文件夹和**u2can**文件夹里的readme有详细说明。

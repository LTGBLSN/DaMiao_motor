from .usb_class import usb_class,can_value_type

